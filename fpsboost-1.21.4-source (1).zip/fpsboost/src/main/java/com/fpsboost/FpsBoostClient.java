package com.fpsboost;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
public class FpsBoostClient implements ClientModInitializer {
  public static KeyBinding menuKey, zoomKey;
  @Override public void onInitializeClient() {
    Config.load();
    menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.fpsboost.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.fpsboost"));
    zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.fpsboost.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.fpsboost"));
    ClientTickEvents.END_CLIENT_TICK.register(c -> {
      while (menuKey.wasPressed()) if (c.currentScreen == null) c.setScreen(new ModMenuScreen());
      Features.tick(c);
    });
    WorldRenderEvents.AFTER_ENTITIES.register(HitboxRenderer::render);
    HudRenderCallback.EVENT.register((ctx, tick) -> HudRenderer.renderAll(ctx, false));
  }
}
