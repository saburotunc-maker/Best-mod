package com.fpsboost;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
public class HitboxRenderer {
  static void line(VertexConsumer vc, MatrixStack.Entry e, float x1, float y1, float z1, float x2, float y2, float z2, int r, int g, int b) {
    float dx = x2 - x1, dy = y2 - y1, dz = z2 - z1; float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (len == 0) return; dx /= len; dy /= len; dz /= len;
    vc.vertex(e, x1, y1, z1).color(r, g, b, 255).normal(e, dx, dy, dz);
    vc.vertex(e, x2, y2, z2).color(r, g, b, 255).normal(e, dx, dy, dz);
  }
  static void box(VertexConsumer vc, MatrixStack.Entry e, Box bb, int rgb) {
    float x1 = (float) bb.minX, y1 = (float) bb.minY, z1 = (float) bb.minZ, x2 = (float) bb.maxX, y2 = (float) bb.maxY, z2 = (float) bb.maxZ;
    int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
    line(vc, e, x1, y1, z1, x2, y1, z1, r, g, b); line(vc, e, x1, y1, z2, x2, y1, z2, r, g, b);
    line(vc, e, x1, y2, z1, x2, y2, z1, r, g, b); line(vc, e, x1, y2, z2, x2, y2, z2, r, g, b);
    line(vc, e, x1, y1, z1, x1, y2, z1, r, g, b); line(vc, e, x2, y1, z1, x2, y2, z1, r, g, b);
    line(vc, e, x1, y1, z2, x1, y2, z2, r, g, b); line(vc, e, x2, y1, z2, x2, y2, z2, r, g, b);
    line(vc, e, x1, y1, z1, x1, y1, z2, r, g, b); line(vc, e, x2, y1, z1, x2, y1, z2, r, g, b);
    line(vc, e, x1, y2, z1, x1, y2, z2, r, g, b); line(vc, e, x2, y2, z1, x2, y2, z2, r, g, b);
  }
  public static void render(WorldRenderContext ctx) {
    Config c = Config.I; if (!c.hitboxes) return;
    MinecraftClient mc = MinecraftClient.getInstance();
    if (mc.world == null || mc.player == null || ctx.consumers() == null || ctx.matrixStack() == null) return;
    MatrixStack ms = ctx.matrixStack(); Vec3d cam = ctx.camera().getPos();
    float td = mc.getRenderTickCounter().getTickDelta(false);
    VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
    ms.push(); ms.translate(-cam.x, -cam.y, -cam.z);
    MatrixStack.Entry en = ms.peek();
    for (Entity e : mc.world.getEntities()) {
      if (e == mc.player || e.isRemoved() || e.squaredDistanceTo(mc.player) > 96 * 96) continue;
      int rgb;
      if (e instanceof PlayerEntity p) rgb = Friends.is(p.getName().getString()) ? Colors.rgb(c.friendColor) : Colors.rgb(c.hitboxColor);
      else if (c.hitboxMobs && e instanceof LivingEntity) rgb = 0xFFFFFF;
      else continue;
      Vec3d lp = e.getLerpedPos(td), pp = e.getPos();
      box(vc, en, e.getBoundingBox().offset(lp.x - pp.x, lp.y - pp.y, lp.z - pp.z), rgb);
    }
    ms.pop();
  }
}
