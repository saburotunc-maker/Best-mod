package com.fpsboost;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
public class HudRenderer {
  static final int[] CH_COLORS = { 0xFFFFFFFF, 0xFF55FF55, 0xFFFF5555, 0xFF55AAFF, 0xFFFFFF55 };
  public static final String[] CH_NAMES = { "White", "Green", "Red", "Blue", "Yellow" };
  public static void renderAll(DrawContext ctx, boolean editing) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (!editing) {
      if (mc.options.hudHidden) return;
      if (mc.currentScreen instanceof HudEditScreen) return;
    }
    for (HudModule m : Modules.ALL) {
      Config.HudState s = m.st();
      if (!s.enabled) continue;
      ctx.getMatrices().push();
      ctx.getMatrices().translate(s.x, s.y, 0);
      float sc = s.scale / 100f;
      ctx.getMatrices().scale(sc, sc, 1f);
      m.draw(ctx, mc);
      ctx.getMatrices().pop();
    }
    if (editing || mc.currentScreen != null) return;
    Config c = Config.I; int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
    if (c.crosshair) {
      int cx = sw / 2, cy = sh / 2, g = c.chGap, s = c.chSize, t = Math.max(1, c.chThick), col = CH_COLORS[Math.floorMod(c.chColor, CH_COLORS.length)];
      int o = t / 2;
      ctx.fill(cx - g - s, cy - o, cx - g, cy - o + t, col);
      ctx.fill(cx + g, cy - o, cx + g + s, cy - o + t, col);
      ctx.fill(cx - o, cy - g - s, cx - o + t, cy - g, col);
      ctx.fill(cx - o, cy + g, cx - o + t, cy + g + s, col);
    }
    if (c.lowHealthWarn && mc.player != null && !mc.player.isDead() && mc.player.getHealth() <= 6f) {
      int a = (int) (45 + 35 * Math.sin(System.currentTimeMillis() / 200.0)); int col = (a << 24) | 0xFF0000; int b = 14;
      ctx.fill(0, 0, sw, b, col); ctx.fill(0, sh - b, sw, sh, col); ctx.fill(0, b, b, sh - b, col); ctx.fill(sw - b, b, sw, sh - b, col);
    }
  }
}
