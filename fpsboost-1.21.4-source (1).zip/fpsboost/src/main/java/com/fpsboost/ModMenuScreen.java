package com.fpsboost;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;
import java.util.function.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.option.GameOptions;
public class ModMenuScreen extends Screen {
  static final int[] ACCENTS = { 0xFF55AAFF, 0xFFFF5577, 0xFF55DD88, 0xFFFFAA33, 0xFFAA66FF };
  static final String[] ACCENT_NAMES = { "Blue", "Pink", "Green", "Orange", "Purple" };
  final String[] tabs = { "HUD", "PvP", "Friends", "Visual", "Performance", "Misc", "Settings" };
  final List<List<Row>> pages = new ArrayList<>();
  final float[] tabAnim = new float[7];
  int tab = 0; float scroll = 0, openAnim = 0; long last = System.nanoTime();
  Row dragging; String input = ""; boolean inputFocus = false;
  int px, py, pw, ph, sw = 90, viewTop, viewBottom, cx, cw;

  public ModMenuScreen() { super(Text.literal("FPS Boost")); }
  static int accent() { return ACCENTS[Math.floorMod(Config.I.accent, ACCENTS.length)]; }
  static int lerp(int a, int b, float t) {
    t = Math.max(0, Math.min(1, t)); int r = 0;
    for (int s = 0; s <= 24; s += 8) { int ca = (a >> s) & 255, cb = (b >> s) & 255; r |= ((int) (ca + (cb - ca) * t) & 255) << s; }
    return r;
  }

  abstract class Row {
    int x, y, w, h = 22;
    abstract void draw(DrawContext c, int mx, int my, float dt, int acc);
    boolean hover(int mx, int my) { return mx >= x && mx < x + w && my >= y && my < y + h && my >= viewTop && my < viewBottom; }
    void click(int mx, int my) {}
    void drag(int mx) {}
  }
  class Header extends Row {
    final String text; final boolean muted;
    Header(String t, boolean muted) { text = t; this.muted = muted; h = 16; }
    void draw(DrawContext c, int mx, int my, float dt, int acc) { c.drawTextWithShadow(textRenderer, text, x + 2, y + 5, muted ? 0xFF888888 : acc); }
  }
  class Toggle extends Row {
    final String label; final BooleanSupplier get; final Consumer<Boolean> set; float a = -1;
    Toggle(String l, BooleanSupplier g, Consumer<Boolean> s) { label = l; get = g; set = s; }
    void draw(DrawContext c, int mx, int my, float dt, int acc) {
      boolean on = get.getAsBoolean(); if (a < 0) a = on ? 1 : 0;
      a += ((on ? 1f : 0f) - a) * Math.min(1f, dt * 14f);
      c.fill(x, y, x + w, y + h, hover(mx, my) ? 0xFF262634 : 0xFF1B1B26);
      c.drawTextWithShadow(textRenderer, label, x + 8, y + 7, 0xFFFFFFFF);
      int sx = x + w - 8 - 30, sy = y + 5;
      c.fill(sx, sy, sx + 30, sy + 12, lerp(0xFF3A3A48, acc, a));
      int kx = sx + 1 + (int) (a * 18); c.fill(kx, sy + 1, kx + 10, sy + 11, 0xFFFFFFFF);
    }
    void click(int mx, int my) { set.accept(!get.getAsBoolean()); }
  }
  class Slider extends Row {
    final String label, suffix; final int min, max; final IntSupplier get; final IntConsumer set;
    Slider(String l, int min, int max, String suffix, IntSupplier g, IntConsumer s) { label = l; this.min = min; this.max = max; this.suffix = suffix; get = g; set = s; }
    int bx() { return x + w - 8 - 110; }
    void draw(DrawContext c, int mx, int my, float dt, int acc) {
      c.fill(x, y, x + w, y + h, hover(mx, my) ? 0xFF262634 : 0xFF1B1B26);
      c.drawTextWithShadow(textRenderer, label, x + 8, y + 7, 0xFFFFFFFF);
      String v = get.getAsInt() + suffix;
      c.drawTextWithShadow(textRenderer, v, bx() - 8 - textRenderer.getWidth(v), y + 7, 0xFFBBBBBB);
      int by = y + h / 2; float t = (get.getAsInt() - min) / (float) (max - min); int fx = bx() + (int) (t * 110);
      c.fill(bx(), by - 1, bx() + 110, by + 1, 0xFF3A3A48);
      c.fill(bx(), by - 1, fx, by + 1, acc);
      c.fill(fx - 2, by - 5, fx + 2, by + 5, 0xFFFFFFFF);
    }
    void click(int mx, int my) { if (mx >= bx() - 4) { dragging = this; drag(mx); } }
    void drag(int mx) {
      float t = Math.max(0f, Math.min(1f, (mx - bx()) / 110f));
      set.accept(min + Math.round(t * (max - min)));
    }
  }
  class Input extends Row {
    void draw(DrawContext c, int mx, int my, float dt, int acc) {
      c.fill(x, y, x + w, y + h, inputFocus ? 0xFF2A2A3C : 0xFF1B1B26);
      if (inputFocus) c.drawBorder(x, y, w, h, acc);
      boolean empty = input.isEmpty() && !inputFocus; boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
      String t = empty ? "Type nickname, press Enter" : input + (inputFocus && blink ? "_" : "");
      c.drawTextWithShadow(textRenderer, t, x + 8, y + 7, empty ? 0xFF777777 : 0xFFFFFFFF);
    }
    void click(int mx, int my) { inputFocus = true; }
  }
  class Btn extends Row {
    final Supplier<String> label; final Runnable run;
    Btn(Supplier<String> l, Runnable r) { label = l; run = r; }
    void draw(DrawContext c, int mx, int my, float dt, int acc) {
      c.fill(x, y, x + w, y + h, lerp(0xFF1B1B26, acc, hover(mx, my) ? 0.45f : 0.2f));
      c.drawCenteredTextWithShadow(textRenderer, label.get(), x + w / 2, y + 7, 0xFFFFFFFF);
    }
    void click(int mx, int my) { run.run(); }
  }

  static GameOptions go() { return MinecraftClient.getInstance().options; }
  Btn colorBtn(String label, IntSupplier get, IntConsumer set) {
    return new Btn(() -> label + ": " + Colors.name(get.getAsInt()), () -> set.accept((get.getAsInt() + 1) % Colors.NAMES.length));
  }
  void buildPages() {
    pages.clear();
    List<Row> hud = new ArrayList<>();
    hud.add(new Header("Style", false));
    hud.add(new Btn(() -> "Text Color: " + HudModule.COLOR_NAMES[Math.floorMod(Config.I.hudColor, HudModule.COLOR_NAMES.length)], () -> Config.I.hudColor = (Config.I.hudColor + 1) % HudModule.COLOR_NAMES.length));
    hud.add(new Toggle("HUD Background", () -> Config.I.hudBackground, v -> Config.I.hudBackground = v));
    hud.add(new Slider("Background Opacity", 0, 255, "", () -> Config.I.hudBgAlpha, v -> Config.I.hudBgAlpha = v));
    hud.add(new Btn(() -> "Edit HUD Layout (drag each module)", () -> client.setScreen(new HudEditScreen(this))));
    hud.add(new Btn(() -> "Reset HUD Layout", () -> { for (HudModule m : Modules.ALL) m.resetPos(); }));
    hud.add(new Header("Modules (" + Modules.ALL.size() + ")", false));
    for (HudModule m : Modules.ALL) hud.add(new Toggle(m.name, () -> m.st().enabled, v -> m.st().enabled = v));
    pages.add(hud);

    List<Row> pvp = new ArrayList<>();
    pvp.add(new Header("Box PvP", false));
    pvp.add(new Btn(() -> "Apply Box PvP Preset (Boxmining)", () -> { Presets.pvp(); buildPages(); }));
    pvp.add(new Header("Hitboxes (friends use friend color)", false));
    pvp.add(new Toggle("Show Player Hitboxes", () -> Config.I.hitboxes, v -> Config.I.hitboxes = v));
    pvp.add(new Toggle("Also Show Mob Hitboxes", () -> Config.I.hitboxMobs, v -> Config.I.hitboxMobs = v));
    pvp.add(colorBtn("Hitbox Color", () -> Config.I.hitboxColor, v -> Config.I.hitboxColor = v));
    pvp.add(new Header("Combat helpers", false));
    pvp.add(new Toggle("Toggle Sprint (auto)", () -> Config.I.toggleSprint, v -> Config.I.toggleSprint = v));
    pvp.add(new Toggle("Toggle Sneak (always)", () -> Config.I.toggleSneak, v -> Config.I.toggleSneak = v));
    pvp.add(new Toggle("Low Health Warning", () -> Config.I.lowHealthWarn, v -> Config.I.lowHealthWarn = v));
    pvp.add(new Toggle("Hide Scoreboard", () -> Config.I.hideScoreboard, v -> Config.I.hideScoreboard = v));
    pvp.add(new Header("Custom Crosshair", false));
    pvp.add(new Toggle("Enable Crosshair", () -> Config.I.crosshair, v -> Config.I.crosshair = v));
    pvp.add(new Slider("Size", 1, 20, "", () -> Config.I.chSize, v -> Config.I.chSize = v));
    pvp.add(new Slider("Gap", 0, 12, "", () -> Config.I.chGap, v -> Config.I.chGap = v));
    pvp.add(new Slider("Thickness", 1, 5, "", () -> Config.I.chThick, v -> Config.I.chThick = v));
    pvp.add(new Btn(() -> "Crosshair Color: " + HudRenderer.CH_NAMES[Math.floorMod(Config.I.chColor, HudRenderer.CH_NAMES.length)], () -> Config.I.chColor = (Config.I.chColor + 1) % HudRenderer.CH_NAMES.length));
    pvp.add(new Header("Zoom - hold C", false));
    pvp.add(new Slider("Zoom FOV", 5, 90, "%", () -> Config.I.zoomPercent, v -> Config.I.zoomPercent = v));
    pages.add(pvp);

    List<Row> fr = new ArrayList<>();
    fr.add(new Header("Add friend (their hitbox turns green)", false));
    fr.add(new Input());
    fr.add(new Btn(() -> "Add Friend", () -> { Friends.add(input); input = ""; buildPages(); }));
    fr.add(new Btn(() -> "Add Player I'm Looking At", () -> { if (Features.lastTarget instanceof PlayerEntity p) { Friends.add(p.getName().getString()); buildPages(); } }));
    fr.add(new Header("Friend list (" + Config.I.friends.size() + ") - click to remove", false));
    for (String n : new ArrayList<>(Config.I.friends)) fr.add(new Btn(() -> n + "   [remove]", () -> { Friends.remove(n); buildPages(); }));
    fr.add(new Header("Name colors", false));
    fr.add(new Toggle("Color Friend Names (nametag)", () -> Config.I.nameColors, v -> Config.I.nameColors = v));
    fr.add(new Toggle("Color Enemy Names", () -> Config.I.colorEnemyNames, v -> Config.I.colorEnemyNames = v));
    fr.add(colorBtn("Friend Color", () -> Config.I.friendColor, v -> Config.I.friendColor = v));
    fr.add(colorBtn("Enemy Color", () -> Config.I.enemyColor, v -> Config.I.enemyColor = v));
    pages.add(fr);

    List<Row> vis = new ArrayList<>();
    vis.add(new Header("Visual", false));
    vis.add(new Toggle("Fullbright", () -> Config.I.fullbright, v -> Config.I.fullbright = v));
    vis.add(new Toggle("No Fire Overlay", () -> Config.I.noFire, v -> Config.I.noFire = v));
    vis.add(new Toggle("No Underwater Overlay", () -> Config.I.noUnderwater, v -> Config.I.noUnderwater = v));
    vis.add(new Toggle("No Hurt Camera Shake", () -> Config.I.noHurtCam, v -> Config.I.noHurtCam = v));
    vis.add(new Toggle("No View Bobbing", () -> Config.I.noBob, v -> Config.I.noBob = v));
    vis.add(new Toggle("Custom FOV", () -> Config.I.customFov, v -> Config.I.customFov = v));
    vis.add(new Slider("FOV", 30, 110, "", () -> Config.I.fov, v -> Config.I.fov = v));
    pages.add(vis);

    List<Row> perf = new ArrayList<>();
    perf.add(new Header("Culling - hide far entities", false));
    perf.add(new Toggle("Players", () -> Config.I.playerCull, v -> Config.I.playerCull = v));
    perf.add(new Slider("Player Distance", 4, 128, "", () -> Config.I.playerDistance, v -> Config.I.playerDistance = v));
    perf.add(new Toggle("Mobs / Animals", () -> Config.I.mobCull, v -> Config.I.mobCull = v));
    perf.add(new Slider("Mob Distance", 4, 128, "", () -> Config.I.mobDistance, v -> Config.I.mobDistance = v));
    perf.add(new Toggle("Dropped Items", () -> Config.I.itemCull, v -> Config.I.itemCull = v));
    perf.add(new Slider("Item Distance", 4, 64, "", () -> Config.I.itemDistance, v -> Config.I.itemDistance = v));
    perf.add(new Toggle("Other Entities", () -> Config.I.entityCull, v -> Config.I.entityCull = v));
    perf.add(new Slider("Other Distance", 8, 128, "", () -> Config.I.entityDistance, v -> Config.I.entityDistance = v));
    perf.add(new Header("Particles", false));
    perf.add(new Toggle("Limit Particles", () -> Config.I.particleLimit, v -> Config.I.particleLimit = v));
    perf.add(new Slider("Particle Distance", 2, 64, "", () -> Config.I.particleDistance, v -> Config.I.particleDistance = v));
    perf.add(new Header("Background", false));
    perf.add(new Toggle("Limit FPS When Unfocused", () -> Config.I.bgFpsLimit, v -> Config.I.bgFpsLimit = v));
    perf.add(new Slider("Unfocused FPS", 5, 60, "", () -> Config.I.bgFps, v -> Config.I.bgFps = v));
    perf.add(new Header("Video settings", false));
    perf.add(new Slider("Render Distance", 2, 32, "", () -> go().getViewDistance().getValue(), v -> go().getViewDistance().setValue(v)));
    perf.add(new Slider("Simulation Distance", 5, 32, "", () -> go().getSimulationDistance().getValue(), v -> go().getSimulationDistance().setValue(v)));
    perf.add(new Slider("Max FPS", 10, 260, "", () -> go().getMaxFps().getValue(), v -> go().getMaxFps().setValue(v)));
    perf.add(new Header("Presets (also change video settings)", false));
    perf.add(new Btn(() -> "Apply Boost Preset", () -> Presets.apply(false)));
    perf.add(new Btn(() -> "Apply Potato Preset (max FPS)", () -> Presets.apply(true)));
    pages.add(perf);

    List<Row> misc = new ArrayList<>();
    misc.add(new Header("Misc", false));
    misc.add(new Toggle("Death Coordinates in Chat", () -> Config.I.deathCoords, v -> Config.I.deathCoords = v));
    misc.add(new Toggle("Auto Respawn", () -> Config.I.autoRespawn, v -> Config.I.autoRespawn = v));
    pages.add(misc);

    List<Row> set = new ArrayList<>();
    set.add(new Header("Settings", false));
    set.add(new Btn(() -> "Accent Color: " + ACCENT_NAMES[Math.floorMod(Config.I.accent, ACCENTS.length)], () -> Config.I.accent = (Config.I.accent + 1) % ACCENTS.length));
    set.add(new Btn(() -> "Reset Everything", () -> { Config.I = new Config(); buildPages(); }));
    set.add(new Header("Right Shift = menu  |  C = zoom (rebind in Controls)", true));
    pages.add(set);
  }

  @Override protected void init() { buildPages(); }

  @Override public void render(DrawContext ctx, int mx, int my, float delta) {
    long now = System.nanoTime(); float dt = Math.min(0.1f, (now - last) / 1e9f); last = now;
    openAnim = Math.min(1f, openAnim + dt * 5f); float e = 1 - (1 - openAnim) * (1 - openAnim);
    ctx.fill(0, 0, width, height, ((int) (0x99 * e)) << 24);
    pw = Math.min(width - 16, 460); ph = Math.min(height - 16, 270);
    px = (width - pw) / 2; py = (height - ph) / 2 + (int) ((1 - e) * 16);
    int acc = accent();
    ctx.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, 0xFF2A2A38);
    ctx.fill(px, py, px + pw, py + ph, 0xF2121218);
    ctx.fill(px, py, px + pw, py + 2, acc);
    ctx.fill(px, py + 2, px + sw, py + ph, 0xFF0D0D13);
    ctx.drawTextWithShadow(textRenderer, "FPS BOOST", px + 12, py + 11, acc);
    ctx.drawTextWithShadow(textRenderer, "v1.3", px + 12, py + 21, 0xFF666666);
    for (int i = 0; i < tabs.length; i++) {
      int ty = py + 36 + i * 22; boolean sel = i == tab;
      boolean hov = mx >= px && mx < px + sw && my >= ty && my < ty + 20;
      tabAnim[i] += ((sel ? 1f : (hov ? 0.4f : 0f)) - tabAnim[i]) * Math.min(1f, dt * 14f);
      ctx.fill(px + 4, ty, px + sw - 4, ty + 20, lerp(0xFF0D0D13, 0xFF1F1F2B, tabAnim[i]));
      if (sel) ctx.fill(px + 4, ty, px + 6, ty + 20, acc);
      ctx.drawTextWithShadow(textRenderer, tabs[i], px + 14, ty + 7, sel ? 0xFFFFFFFF : 0xFFAAAAAA);
    }
    cx = px + sw + 10; cw = pw - sw - 22; viewTop = py + 32; viewBottom = py + ph - 8;
    ctx.drawTextWithShadow(textRenderer, tabs[tab], cx, py + 12, 0xFFFFFFFF);
    ctx.fill(cx, py + 25, cx + cw, py + 26, 0xFF2A2A38);
    List<Row> rows = pages.get(tab); int total = 0;
    for (Row r : rows) total += r.h + 3;
    float maxScroll = Math.max(0, total - (viewBottom - viewTop));
    scroll = Math.max(0, Math.min(maxScroll, scroll));
    ctx.enableScissor(cx - 2, viewTop, cx + cw + 2, viewBottom);
    int y = viewTop - (int) scroll + 2;
    for (Row r : rows) {
      r.x = cx; r.y = y; r.w = cw;
      if (y + r.h > viewTop && y < viewBottom) r.draw(ctx, mx, my, dt, acc);
      y += r.h + 3;
    }
    ctx.disableScissor();
    if (maxScroll > 0) {
      int vh = viewBottom - viewTop; int bh = Math.max(14, (int) (vh * vh / (float) total));
      int by = viewTop + (int) ((vh - bh) * (scroll / maxScroll));
      ctx.fill(px + pw - 5, by, px + pw - 3, by + bh, acc);
    }
  }

  @Override public boolean mouseClicked(double mx, double my, int b) {
    int x = (int) mx, y = (int) my;
    if (b == 0) {
      inputFocus = false;
      for (int i = 0; i < tabs.length; i++) {
        int ty = py + 36 + i * 22;
        if (x >= px && x < px + sw && y >= ty && y < ty + 20) { tab = i; scroll = 0; return true; }
      }
      if (y >= viewTop && y < viewBottom) for (Row r : pages.get(tab)) if (r.hover(x, y)) { r.click(x, y); return true; }
    }
    return super.mouseClicked(mx, my, b);
  }
  @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
    if (dragging != null) { dragging.drag((int) mx); return true; }
    return super.mouseDragged(mx, my, b, dx, dy);
  }
  @Override public boolean mouseReleased(double mx, double my, int b) { dragging = null; return super.mouseReleased(mx, my, b); }
  @Override public boolean mouseScrolled(double mx, double my, double h, double v) { scroll -= (float) v * 18f; return true; }
  @Override public boolean keyPressed(int key, int scan, int mods) {
    if (inputFocus) {
      if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!input.isEmpty()) input = input.substring(0, input.length() - 1); return true; }
      if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { Friends.add(input); input = ""; buildPages(); return true; }
      if (key == GLFW.GLFW_KEY_ESCAPE) { inputFocus = false; return true; }
      if (key == GLFW.GLFW_KEY_V && Screen.hasControlDown()) {
        for (char ch : client.keyboard.getClipboard().toCharArray()) if ((Character.isLetterOrDigit(ch) || ch == '_') && input.length() < 16) input += ch;
        return true;
      }
      return true;
    }
    if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
    return super.keyPressed(key, scan, mods);
  }
  @Override public boolean charTyped(char chr, int mods) {
    if (inputFocus) { if ((Character.isLetterOrDigit(chr) || chr == '_') && input.length() < 16) input += chr; return true; }
    return super.charTyped(chr, mods);
  }
  @Override public boolean shouldPause() { return false; }
  @Override public void close() { Config.save(); go().write(); super.close(); }
}
