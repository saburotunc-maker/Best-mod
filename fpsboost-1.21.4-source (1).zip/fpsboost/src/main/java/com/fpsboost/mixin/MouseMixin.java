package com.fpsboost.mixin;
import com.fpsboost.Stats;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Mouse.class)
public class MouseMixin {
  @Inject(method = "onMouseButton", at = @At("HEAD"))
  private void fpsboost$click(long w, int button, int action, int mods, CallbackInfo ci) { if (action == 1 && (button == 0 || button == 1)) Stats.click(button); }
}
