package com.fpsboost.mixin;
import com.fpsboost.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
  @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
  private void fpsboost$cull(Entity e, Frustum f, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (mc.player == null || e == mc.player || e == mc.getCameraEntity() || e == mc.player.getVehicle()) return;
    Config c = Config.I; double d2 = mc.player.squaredDistanceTo(e);
    int lim = -1;
    if (e instanceof PlayerEntity) { if (c.playerCull) lim = c.playerDistance; }
    else if (e instanceof LivingEntity) { if (c.mobCull) lim = c.mobDistance; }
    else if (e instanceof ItemEntity) { if (c.itemCull) lim = c.itemDistance; }
    else if (c.entityCull) lim = c.entityDistance;
    if (lim >= 0 && d2 > (double) lim * lim) cir.setReturnValue(false);
  }
}
