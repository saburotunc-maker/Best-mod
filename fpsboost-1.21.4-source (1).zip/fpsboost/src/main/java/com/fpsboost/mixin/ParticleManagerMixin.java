package com.fpsboost.mixin;
import com.fpsboost.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
  @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;", at = @At("HEAD"), cancellable = true)
  private void fpsboost$limit(ParticleEffect p, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<Particle> cir) {
    Config c = Config.I; MinecraftClient mc = MinecraftClient.getInstance();
    if (!c.particleLimit || mc.player == null) return;
    if (mc.player.squaredDistanceTo(x, y, z) > (double) c.particleDistance * c.particleDistance) cir.setReturnValue(null);
  }
}
