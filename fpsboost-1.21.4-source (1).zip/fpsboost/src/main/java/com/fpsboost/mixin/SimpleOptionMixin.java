package com.fpsboost.mixin;
import com.fpsboost.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(SimpleOption.class)
public class SimpleOptionMixin {
  @Inject(method = "getValue", at = @At("HEAD"), cancellable = true)
  private void fpsboost$gamma(CallbackInfoReturnable<Object> cir) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (Config.I.fullbright && mc != null && mc.options != null && (Object) this == mc.options.getGamma()) cir.setReturnValue(15.0);
  }
}
