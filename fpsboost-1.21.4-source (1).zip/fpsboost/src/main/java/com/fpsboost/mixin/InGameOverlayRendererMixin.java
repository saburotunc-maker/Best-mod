package com.fpsboost.mixin;
import com.fpsboost.Config;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
  @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
  private static void fpsboost$fire(CallbackInfo ci) { if (Config.I.noFire) ci.cancel(); }
  @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true, require = 0)
  private static void fpsboost$water(CallbackInfo ci) { if (Config.I.noUnderwater) ci.cancel(); }
}
