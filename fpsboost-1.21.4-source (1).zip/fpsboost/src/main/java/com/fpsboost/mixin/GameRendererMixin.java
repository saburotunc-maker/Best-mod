package com.fpsboost.mixin;
import com.fpsboost.Config;
import com.fpsboost.FpsBoostClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(GameRenderer.class)
public class GameRendererMixin {
  @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
  private void fpsboost$hurt(CallbackInfo ci) { if (Config.I.noHurtCam) ci.cancel(); }
  @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
  private void fpsboost$zoom(Camera cam, float t, boolean changing, CallbackInfoReturnable<Double> cir) {
    if (FpsBoostClient.zoomKey != null && FpsBoostClient.zoomKey.isPressed())
      cir.setReturnValue(cir.getReturnValue() * Config.I.zoomPercent / 100.0);
  }
}
