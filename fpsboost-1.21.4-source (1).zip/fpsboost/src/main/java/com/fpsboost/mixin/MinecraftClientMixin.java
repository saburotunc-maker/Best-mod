package com.fpsboost.mixin;
import com.fpsboost.Config;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
  @Inject(method = "getFramerateLimit", at = @At("HEAD"), cancellable = true, require = 0)
  private void fpsboost$bg(CallbackInfoReturnable<Integer> cir) {
    Config c = Config.I; if (!c.bgFpsLimit) return;
    MinecraftClient mc = (MinecraftClient) (Object) this;
    if (mc.getWindow() == null) return;
    if (GLFW.glfwGetWindowAttrib(mc.getWindow().getHandle(), GLFW.GLFW_FOCUSED) == 0) cir.setReturnValue(c.bgFps);
  }
}
