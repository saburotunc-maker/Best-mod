package com.fpsboost.mixin;
import com.fpsboost.Config;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(InGameHud.class)
public class InGameHudMixin {
  @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
  private void fpsboost$crosshair(CallbackInfo ci) { if (Config.I.crosshair) ci.cancel(); }
  @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true, require = 0)
  private void fpsboost$scoreboard(CallbackInfo ci) { if (Config.I.hideScoreboard) ci.cancel(); }
}
