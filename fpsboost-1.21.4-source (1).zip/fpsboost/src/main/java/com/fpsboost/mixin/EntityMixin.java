package com.fpsboost.mixin;
import com.fpsboost.Colors;
import com.fpsboost.Config;
import com.fpsboost.Friends;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Entity.class)
public class EntityMixin {
  @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
  private void fpsboost$names(CallbackInfoReturnable<Text> cir) {
    Config c = Config.I; if (!c.nameColors) return;
    if (!((Object) this instanceof AbstractClientPlayerEntity p)) return;
    if (p == MinecraftClient.getInstance().player) return;
    int rgb;
    if (Friends.is(p.getName().getString())) rgb = Colors.rgb(c.friendColor);
    else if (c.colorEnemyNames) rgb = Colors.rgb(c.enemyColor);
    else return;
    final int col = rgb;
    cir.setReturnValue(cir.getReturnValue().copy().styled(s -> s.withColor(col)));
  }
}
