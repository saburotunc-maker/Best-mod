package com.fpsboost;
public class Friends {
  public static boolean is(String n) {
    if (n == null) return false;
    for (String f : Config.I.friends) if (f.equalsIgnoreCase(n)) return true;
    return false;
  }
  public static void add(String n) {
    if (n == null) return; n = n.trim();
    if (n.isEmpty() || is(n)) return;
    Config.I.friends.add(n); Config.save();
  }
  public static void remove(String n) { Config.I.friends.removeIf(f -> f.equalsIgnoreCase(n)); Config.save(); }
}
