package com.fpsboost;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;
public class Presets {
  public static void apply(boolean potato) {
    MinecraftClient mc = MinecraftClient.getInstance(); GameOptions o = mc.options;
    o.getViewDistance().setValue(potato ? 5 : 8);
    o.getSimulationDistance().setValue(potato ? 5 : 6);
    o.getEntityDistanceScaling().setValue(potato ? 0.5 : 0.75);
    o.getEntityShadows().setValue(false);
    o.getParticles().setValue(potato ? ParticlesMode.MINIMAL : ParticlesMode.DECREASED);
    o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
    o.write();
    Config c = Config.I;
    c.playerCull = c.mobCull = c.itemCull = c.entityCull = c.particleLimit = c.bgFpsLimit = true;
    c.playerDistance = potato ? 16 : 32; c.mobDistance = potato ? 24 : 48;
    c.itemDistance = potato ? 8 : 16;    c.entityDistance = potato ? 24 : 48;
    c.particleDistance = potato ? 8 : 16;
    Config.save();
  }
  static void put(String id, int x, int y) {
    for (HudModule m : Modules.ALL) if (m.id.equals(id)) { Config.HudState s = m.st(); s.enabled = true; s.x = x; s.y = y; s.scale = 100; }
  }
  public static void pvp() {
    put("fps", 4, 4); put("cps", 4, 20); put("ping", 4, 36); put("combo", 4, 52); put("reach", 4, 68); put("pvpitems", 4, 84);
    put("keys", 4, 132); put("armor", 70, 132); put("nearby", 70, 4); put("potions", 190, 4); put("target", 190, 70);
    Config c = Config.I;
    c.hitboxes = true; c.crosshair = true; c.toggleSprint = true; c.lowHealthWarn = true; c.hideScoreboard = true;
    c.nameColors = true; c.colorEnemyNames = true; c.noFire = true;
    c.playerCull = true; c.playerDistance = 96; c.mobCull = true; c.mobDistance = 24; c.itemCull = true; c.itemDistance = 16;
    c.entityCull = true; c.entityDistance = 32; c.particleLimit = true; c.particleDistance = 12;
    Config.save();
  }
}
