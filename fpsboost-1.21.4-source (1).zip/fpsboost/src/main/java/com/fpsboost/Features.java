package com.fpsboost;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
public class Features {
  static boolean lastSneak = false, wasDead = false, hasLast = false;
  static int deadTicks = 0, prevHurt = 0, prevSelfHurt = 0; static double lx, lz;
  static LivingEntity prevT; static long lastHitTime = 0;
  public static double speed = 0, reach = 0; public static int combo = 0;
  public static LivingEntity lastTarget; public static long lastTargetTime;
  public static void tick(MinecraftClient c) {
    Config cf = Config.I;
    if (cf.customFov && c.options.getFov().getValue() != cf.fov) c.options.getFov().setValue(cf.fov);
    if (cf.noBob && c.options.getBobView().getValue()) c.options.getBobView().setValue(false);
    if (c.player == null) { hasLast = false; wasDead = false; combo = 0; return; }
    double x = c.player.getX(), z = c.player.getZ();
    if (hasLast) speed = speed * 0.6 + Math.sqrt((x - lx) * (x - lx) + (z - lz) * (z - lz)) * 20 * 0.4;
    lx = x; lz = z; hasLast = true;
    if (cf.toggleSprint && c.options.forwardKey.isPressed() && !c.player.isSneaking() && !c.player.horizontalCollision
        && !c.player.isUsingItem() && c.player.getHungerManager().getFoodLevel() > 6) c.player.setSprinting(true);
    if (cf.toggleSneak) { if (c.currentScreen == null) c.options.sneakKey.setPressed(true); lastSneak = true; }
    else if (lastSneak) { c.options.sneakKey.setPressed(false); lastSneak = false; }
    if (c.targetedEntity instanceof LivingEntity le) { lastTarget = le; lastTargetTime = System.currentTimeMillis(); }
    // combo + reach tracking
    if (c.player.hurtTime > prevSelfHurt) combo = 0;
    prevSelfHurt = c.player.hurtTime;
    LivingEntity t = lastTarget;
    if (t != null) {
      if (t == prevT && t.hurtTime > prevHurt && System.currentTimeMillis() - Stats.lastLeft < 600) {
        combo++; lastHitTime = System.currentTimeMillis();
        Box bb = t.getBoundingBox(); Vec3d ep = c.player.getEyePos();
        double dx = ep.x - MathHelper.clamp(ep.x, bb.minX, bb.maxX), dy = ep.y - MathHelper.clamp(ep.y, bb.minY, bb.maxY), dz = ep.z - MathHelper.clamp(ep.z, bb.minZ, bb.maxZ);
        reach = Math.sqrt(dx * dx + dy * dy + dz * dz);
      }
      prevHurt = t.hurtTime;
    } else prevHurt = 0;
    prevT = t;
    if (combo > 0 && System.currentTimeMillis() - lastHitTime > 3000) combo = 0;
    boolean dead = c.player.isDead();
    if (dead && !wasDead && cf.deathCoords)
      c.player.sendMessage(Text.literal("You died at X: " + c.player.getBlockX() + " Y: " + c.player.getBlockY() + " Z: " + c.player.getBlockZ()), false);
    if (dead) { deadTicks++; if (cf.autoRespawn && deadTicks == 15) c.player.requestRespawn(); } else deadTicks = 0;
    wasDead = dead;
  }
}
