package com.fpsboost;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
public class HudEditScreen extends Screen {
  final Screen parent; HudModule active; int offX, offY;
  protected HudEditScreen(Screen parent) { super(Text.literal("HUD")); this.parent = parent; }
  HudModule hovered(double mx, double my) {
    for (int i = Modules.ALL.size() - 1; i >= 0; i--) if (Modules.ALL.get(i).hit(mx, my)) return Modules.ALL.get(i);
    return null;
  }
  @Override public void render(DrawContext ctx, int mx, int my, float d) {
    ctx.fill(0, 0, width, height, 0x66000000);
    ctx.fill(width / 2, 0, width / 2 + 1, height, 0x22FFFFFF);
    ctx.fill(0, height / 2, width, height / 2 + 1, 0x22FFFFFF);
    HudRenderer.renderAll(ctx, true);
    HudModule hov = hovered(mx, my); boolean any = false;
    for (HudModule m : Modules.ALL) {
      Config.HudState s = m.st(); if (!s.enabled) continue; any = true;
      float sc = s.scale / 100f;
      int col = m == active ? 0xFF55DD88 : (m == hov ? 0xFFFFFF55 : 0x66FFFFFF);
      ctx.drawBorder(s.x - 1, s.y - 1, (int) (m.w * sc) + 2, (int) (m.h * sc) + 2, col);
      if (m == active || m == hov) ctx.drawTextWithShadow(textRenderer, m.name + " (" + s.scale + "%)", s.x, Math.max(0, s.y - 10), 0xFFFFFFFF);
    }
    ctx.drawCenteredTextWithShadow(textRenderer, "Drag modules  |  Scroll = resize  |  R = reset  |  ESC = back", width / 2, 8, 0xFFFFFFFF);
    if (!any) ctx.drawCenteredTextWithShadow(textRenderer, "No HUD module enabled. Enable some in the HUD tab.", width / 2, height / 2 + 6, 0xFFFFAA55);
  }
  @Override public boolean mouseClicked(double x, double y, int b) {
    active = hovered(x, y);
    if (active != null) { offX = (int) x - active.st().x; offY = (int) y - active.st().y; }
    return true;
  }
  @Override public boolean mouseReleased(double x, double y, int b) { active = null; return true; }
  @Override public boolean mouseDragged(double x, double y, int b, double dx, double dy) {
    if (active != null) {
      Config.HudState s = active.st();
      s.x = Math.max(0, Math.min(width - 10, (int) x - offX));
      s.y = Math.max(0, Math.min(height - 10, (int) y - offY));
    }
    return true;
  }
  @Override public boolean mouseScrolled(double x, double y, double h, double v) {
    HudModule m = hovered(x, y);
    if (m != null) { Config.HudState s = m.st(); s.scale = Math.max(50, Math.min(250, s.scale + (int) (v * 10))); }
    return true;
  }
  @Override public boolean keyPressed(int key, int scan, int mods) {
    if (key == GLFW.GLFW_KEY_R) { for (HudModule m : Modules.ALL) m.resetPos(); return true; }
    return super.keyPressed(key, scan, mods);
  }
  @Override public boolean shouldPause() { return false; }
  @Override public void close() { Config.save(); client.setScreen(parent); }
}
