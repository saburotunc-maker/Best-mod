package com.fpsboost;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
public class Modules {
  public static final List<HudModule> ALL = new ArrayList<>();
  static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
  static int slot = 0;
  static void add(String id, String name, boolean en, Function<MinecraftClient, String> f) {
    int x = 4 + (slot / 13) * 125, y = 4 + (slot % 13) * 16; slot++;
    ALL.add(new HudModule(id, name, en, x, y) {
      @Override public void draw(DrawContext c, MinecraftClient mc) { box(c, mc, f.apply(mc)); }
    });
  }
  static String cap(String s) { return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1); }
  static {
    add("fps", "FPS", true, mc -> "FPS: " + mc.getCurrentFps());
    add("cps", "CPS", true, mc -> "CPS: " + Stats.cps(0) + " | " + Stats.cps(1));
    add("coords", "Coordinates", true, mc -> mc.player == null ? "XYZ: -" : "XYZ: " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
    add("nether", "Nether Coords", false, mc -> mc.player == null ? "Nether: -" : "Nether: " + (mc.player.getBlockX() / 8) + " " + (mc.player.getBlockZ() / 8));
    add("chunk", "Chunk Position", false, mc -> mc.player == null ? "Chunk: -" : "Chunk: " + (mc.player.getBlockX() >> 4) + " " + (mc.player.getBlockZ() >> 4));
    add("ping", "Ping", false, mc -> {
      if (mc.player == null || mc.getNetworkHandler() == null) return "Ping: -";
      var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
      return e == null ? "Ping: -" : "Ping: " + e.getLatency() + "ms";
    });
    add("combo", "Combo Counter", false, mc -> "Combo: " + Features.combo);
    add("reach", "Reach Display", false, mc -> String.format("Reach: %.2f", Features.reach));
    add("speed", "Speed", false, mc -> String.format("Speed: %.1f b/s", Features.speed));
    add("dir", "Direction", false, mc -> mc.player == null ? "Facing: -" : "Facing: " + cap(mc.player.getHorizontalFacing().name().toLowerCase()));
    add("angles", "Yaw / Pitch", false, mc -> mc.player == null ? "Yaw/Pitch: -" : String.format("%.1f / %.1f", MathHelper.wrapDegrees(mc.player.getYaw()), mc.player.getPitch()));
    add("biome", "Biome", false, mc -> {
      if (mc.player == null || mc.world == null) return "Biome: -";
      String b = mc.world.getBiome(mc.player.getBlockPos()).getKey().map(k -> k.getValue().getPath()).orElse("unknown");
      return "Biome: " + cap(b.replace('_', ' '));
    });
    add("light", "Light Level", false, mc -> mc.player == null || mc.world == null ? "Light: -" : "Light: " + mc.world.getLightLevel(mc.player.getBlockPos()));
    add("gametime", "Game Time", false, mc -> {
      if (mc.world == null) return "Day -";
      long t = mc.world.getTimeOfDay(); long tod = t % 24000;
      return String.format("Day %d  %02d:%02d", t / 24000, (int) ((tod / 1000 + 6) % 24), (int) ((tod % 1000) * 60 / 1000));
    });
    add("clock", "Real Clock", false, mc -> LocalTime.now().format(FMT));
    add("ram", "Memory", false, mc -> {
      Runtime r = Runtime.getRuntime();
      return "RAM: " + ((r.totalMemory() - r.freeMemory()) >> 20) + "/" + (r.maxMemory() >> 20) + "MB";
    });
    add("health", "Health", false, mc -> mc.player == null ? "HP: -" : String.format("HP: %.1f", mc.player.getHealth()));
    add("food", "Hunger", false, mc -> mc.player == null ? "Food: -" : "Food: " + mc.player.getHungerManager().getFoodLevel());
    add("xp", "XP Level", false, mc -> mc.player == null ? "XP: -" : "XP Level: " + mc.player.experienceLevel);
    add("hand", "Held Item", false, mc -> {
      if (mc.player == null) return "Hand: -";
      ItemStack s = mc.player.getMainHandStack(); if (s.isEmpty()) return "Hand: -";
      String n = s.getName().getString();
      return s.isDamageable() ? n + " (" + (s.getMaxDamage() - s.getDamage()) + "/" + s.getMaxDamage() + ")" : n;
    });
    add("count", "Item Counter", false, mc -> {
      if (mc.player == null) return "Count: -";
      ItemStack s = mc.player.getMainHandStack();
      return s.isEmpty() ? "Count: -" : "Count: " + mc.player.getInventory().count(s.getItem());
    });
    add("lookat", "Looking At", false, mc -> {
      if (mc.world == null || mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return "Looking at: -";
      BlockPos bp = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
      return "Looking at: " + mc.world.getBlockState(bp).getBlock().getName().getString();
    });
    add("server", "Server", false, mc -> {
      if (mc.getCurrentServerEntry() == null) return "Singleplayer";
      int n = mc.getNetworkHandler() == null ? 0 : mc.getNetworkHandler().getPlayerList().size();
      return mc.getCurrentServerEntry().address + " (" + n + ")";
    });
    add("watermark", "Watermark", false, mc -> "FPS Boost v1.2");
    ALL.add(new HudModule("nearby", "Nearby Players", false, 129, 4) {
      @Override public void draw(DrawContext c, MinecraftClient mc) {
        TextRenderer tr = mc.textRenderer; List<String> L = new ArrayList<>(); List<Integer> C = new ArrayList<>();
        if (mc.world != null && mc.player != null) {
          List<PlayerEntity> ps = new ArrayList<PlayerEntity>(mc.world.getPlayers()); ps.remove(mc.player);
          ps.sort(Comparator.comparingDouble(p -> p.squaredDistanceTo(mc.player)));
          for (int i = 0; i < ps.size() && i < 8; i++) {
            PlayerEntity p = ps.get(i); String n = p.getName().getString();
            L.add(n + "  " + (int) Math.ceil(p.getHealth()) + "hp  " + (int) p.distanceTo(mc.player) + "m");
            C.add(Friends.is(n) ? Colors.argb(Config.I.friendColor) : (Config.I.colorEnemyNames ? Colors.argb(Config.I.enemyColor) : 0xFFFFFFFF));
          }
        }
        if (L.isEmpty()) { L.add("No players nearby"); C.add(0xFFAAAAAA); }
        int mw = 0; for (String t : L) mw = Math.max(mw, tr.getWidth(t));
        w = mw + 8; h = L.size() * 10 + 14;
        if (Config.I.hudBackground && Config.I.hudBgAlpha > 0) c.fill(0, 0, w, h, Config.I.hudBgAlpha << 24);
        c.drawTextWithShadow(tr, "Players", 4, 3, textColor());
        for (int i = 0; i < L.size(); i++) c.drawTextWithShadow(tr, L.get(i), 4, 13 + i * 10, C.get(i));
      }
    });
    ALL.add(new HudModule("pvpitems", "PvP Items", false, 129, 4 + 13 * 16 - 100) {
      @Override public void draw(DrawContext c, MinecraftClient mc) {
        if (mc.player == null) { box(c, mc, "PvP Items"); return; }
        var inv = mc.player.getInventory();
        box(c, mc, "Totems: " + inv.count(Items.TOTEM_OF_UNDYING), "GApples: " + inv.count(Items.GOLDEN_APPLE),
            "Pearls: " + inv.count(Items.ENDER_PEARL), "Crystals: " + inv.count(Items.END_CRYSTAL));
      }
    });
    ALL.add(new HudModule("potions", "Potion Effects", false, 254, 4) {
      @Override public void draw(DrawContext c, MinecraftClient mc) {
        List<String> L = new ArrayList<>();
        if (mc.player != null) for (StatusEffectInstance e : mc.player.getStatusEffects()) {
          String n = e.getEffectType().value().getName().getString(); int sec = e.getDuration() / 20;
          L.add(n + " " + (e.getAmplifier() + 1) + (e.getDuration() < 0 ? " inf" : " " + (sec / 60) + ":" + String.format("%02d", sec % 60)));
        }
        if (L.isEmpty()) L.add("No effects");
        box(c, mc, L.toArray(new String[0]));
      }
    });
    ALL.add(new HudModule("target", "Target HUD", false, 254, 60) {
      @Override public void draw(DrawContext c, MinecraftClient mc) {
        LivingEntity t = Features.lastTarget;
        if (t == null || t.isRemoved() || System.currentTimeMillis() - Features.lastTargetTime > 3000) { box(c, mc, "Target: -"); return; }
        float hp = t.getHealth(), mx = Math.max(1f, t.getMaxHealth());
        box(c, mc, t.getName().getString(), String.format("HP: %.1f / %.1f", hp, mx));
        int bw = w - 8; c.fill(4, h, 4 + bw, h + 3, 0xFF333333);
        c.fill(4, h, 4 + (int) (bw * Math.max(0f, Math.min(1f, hp / mx))), h + 3, 0xFF55DD55); h += 6;
      }
    });
    ALL.add(new HudModule("keys", "Keystrokes", false, 254, 110) {
      @Override public void draw(DrawContext c, MinecraftClient mc) {
        TextRenderer tr = mc.textRenderer; var o = mc.options; w = 60; h = 70;
        key(c, tr, 21, 0, 18, 18, "W", o.forwardKey.isPressed());
        key(c, tr, 0, 20, 18, 18, "A", o.leftKey.isPressed());
        key(c, tr, 21, 20, 18, 18, "S", o.backKey.isPressed());
        key(c, tr, 42, 20, 18, 18, "D", o.rightKey.isPressed());
        key(c, tr, 0, 40, 29, 18, "LMB", o.attackKey.isPressed());
        key(c, tr, 31, 40, 29, 18, "RMB", o.useKey.isPressed());
        key(c, tr, 0, 60, 60, 10, "", o.jumpKey.isPressed());
      }
    });
    ALL.add(new HudModule("armor", "Armor HUD", false, 254, 190) {
      @Override public void draw(DrawContext c, MinecraftClient mc) {
        w = 56; h = 72;
        if (mc.player == null) { c.drawTextWithShadow(mc.textRenderer, "Armor", 0, 0, 0xFFFFFFFF); return; }
        EquipmentSlot[] S = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
        for (int i = 0; i < 4; i++) {
          ItemStack st = mc.player.getEquippedStack(S[i]);
          if (st.isEmpty()) continue;
          c.drawItem(st, 0, i * 18);
          if (st.isDamageable()) c.drawText(mc.textRenderer, String.valueOf(st.getMaxDamage() - st.getDamage()), 20, i * 18 + 5, 0xFFFFFFFF, true);
        }
      }
    });
  }
}
