package com.fpsboost;
import java.util.ArrayDeque;
public class Stats {
  static final ArrayDeque<Long> L = new ArrayDeque<>(), R = new ArrayDeque<>();
  public static long lastLeft = 0;
  public static void click(int b) { (b == 0 ? L : R).add(System.currentTimeMillis()); if (b == 0) lastLeft = System.currentTimeMillis(); }
  public static int cps(int b) {
    ArrayDeque<Long> q = b == 0 ? L : R; long n = System.currentTimeMillis();
    while (!q.isEmpty() && n - q.peekFirst() > 1000) q.pollFirst();
    return q.size();
  }
}
