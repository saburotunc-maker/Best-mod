package com.fpsboost;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;
public class Config {
  public static Config I = new Config();
  public static class HudState {
    public boolean enabled; public int x, y, scale = 100;
    public HudState() {}
    public HudState(boolean e, int x, int y) { this.enabled = e; this.x = x; this.y = y; }
  }
  public boolean playerCull = true; public int playerDistance = 48;
  public boolean mobCull = true;    public int mobDistance = 64;
  public boolean itemCull = true;   public int itemDistance = 24;
  public boolean entityCull = true; public int entityDistance = 64; // other entities
  public boolean particleLimit = true; public int particleDistance = 24;
  public boolean bgFpsLimit = true; public int bgFps = 15;
  public boolean noFire, noHurtCam, fullbright, toggleSprint;
  public int zoomPercent = 25;
  public boolean toggleSneak, hitboxes, crosshair, noUnderwater, noBob, customFov, deathCoords, autoRespawn, lowHealthWarn;
  public int fov = 90, chSize = 5, chGap = 3, chThick = 1, chColor = 0, hudColor = 0, hudBgAlpha = 144;
  public boolean hudBackground = true;
  public int accent = 0;
  public boolean hideScoreboard, nameColors = true, colorEnemyNames, hitboxMobs;
  public int friendColor = 2, enemyColor = 1, hitboxColor = 0;
  public List<String> friends = new ArrayList<>();
  public Map<String, HudState> modules = new LinkedHashMap<>();
  static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("fpsboost.json"); }
  public static void load() {
    try { if (Files.exists(file())) I = new Gson().fromJson(Files.readString(file()), Config.class); } catch (Exception e) { I = new Config(); }
    if (I == null) I = new Config();
    if (I.modules == null) I.modules = new LinkedHashMap<>();
    if (I.friends == null) I.friends = new ArrayList<>();
  }
  public static void save() {
    try { Files.writeString(file(), new GsonBuilder().setPrettyPrinting().create().toJson(I)); } catch (Exception ignored) {}
  }
}
