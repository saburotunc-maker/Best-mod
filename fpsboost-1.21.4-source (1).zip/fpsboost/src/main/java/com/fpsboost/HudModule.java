package com.fpsboost;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
public abstract class HudModule {
  public final String id, name; final boolean defEnabled; final int defX, defY;
  public int w = 50, h = 14;
  public HudModule(String id, String name, boolean en, int x, int y) { this.id = id; this.name = name; this.defEnabled = en; this.defX = x; this.defY = y; }
  public Config.HudState st() { return Config.I.modules.computeIfAbsent(id, k -> new Config.HudState(defEnabled, defX, defY)); }
  public abstract void draw(DrawContext ctx, MinecraftClient mc);
  public void resetPos() { Config.HudState s = st(); s.x = defX; s.y = defY; s.scale = 100; }
  public boolean hit(double mx, double my) {
    Config.HudState s = st(); float sc = s.scale / 100f;
    return s.enabled && mx >= s.x && my >= s.y && mx <= s.x + w * sc && my <= s.y + h * sc;
  }
  public static final String[] COLOR_NAMES = { "White", "Accent", "Rainbow", "Green", "Yellow", "Red" };
  static int hsv(float h) {
    float f = h * 6 - (int) (h * 6), q = 1 - f; float r, g, b;
    switch (((int) (h * 6)) % 6) { case 0: r = 1; g = f; b = 0; break; case 1: r = q; g = 1; b = 0; break; case 2: r = 0; g = 1; b = f; break;
      case 3: r = 0; g = q; b = 1; break; case 4: r = f; g = 0; b = 1; break; default: r = 1; g = 0; b = q; }
    return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
  }
  public static int textColor() {
    switch (Config.I.hudColor) {
      case 1: return ModMenuScreen.accent();
      case 2: return hsv((System.currentTimeMillis() % 4000) / 4000f);
      case 3: return 0xFF55FF55; case 4: return 0xFFFFFF55; case 5: return 0xFFFF5555;
      default: return 0xFFFFFFFF;
    }
  }
  protected void box(DrawContext ctx, MinecraftClient mc, String... lines) {
    TextRenderer tr = mc.textRenderer; int mw = 0;
    for (String s : lines) mw = Math.max(mw, tr.getWidth(s));
    w = mw + 8; h = lines.length * 10 + 4;
    if (Config.I.hudBackground && Config.I.hudBgAlpha > 0) ctx.fill(0, 0, w, h, Config.I.hudBgAlpha << 24);
    int col = textColor(), y = 3; for (String s : lines) { ctx.drawTextWithShadow(tr, s, 4, y, col); y += 10; }
  }
  protected static void key(DrawContext c, TextRenderer tr, int x, int y, int kw, int kh, String l, boolean p) {
    c.fill(x, y, x + kw, y + kh, p ? 0xB0FFFFFF : 0x90000000);
    int tw = tr.getWidth(l);
    c.drawText(tr, l, x + (kw - tw) / 2, y + (kh - 8) / 2, p ? 0xFF000000 : 0xFFFFFFFF, false);
  }
}
