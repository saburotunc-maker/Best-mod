package com.fpsboost;
public class Colors {
  public static final String[] NAMES = { "White", "Red", "Green", "Blue", "Aqua", "Yellow", "Pink", "Orange", "Purple" };
  static final int[] RGB = { 0xFFFFFF, 0xFF5555, 0x55FF55, 0x5555FF, 0x55FFFF, 0xFFFF55, 0xFF55FF, 0xFFAA00, 0xAA55FF };
  public static int rgb(int i) { return RGB[Math.floorMod(i, RGB.length)]; }
  public static int argb(int i) { return 0xFF000000 | rgb(i); }
  public static String name(int i) { return NAMES[Math.floorMod(i, NAMES.length)]; }
}
