# FPS Boost 1.1 (Fabric 1.21.4)
Build: JDK 21 + Gradle 8.12 -> `gradle build` -> build/libs/fpsboost-1.3.0.jar
Keys: Right Shift = menu, C = zoom.
